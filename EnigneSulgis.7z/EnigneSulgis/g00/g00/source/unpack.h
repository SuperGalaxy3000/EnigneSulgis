#pragma		once


int	LzssUnPack(BYTE *srcdata, BYTE* buf);
int	LzssUnPack32(BYTE *srcdata, BYTE* buf);
