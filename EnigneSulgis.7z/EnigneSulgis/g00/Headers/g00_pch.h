#include	<windows.h>
#include	<vector>
#include	<boost/scoped_array.hpp>
