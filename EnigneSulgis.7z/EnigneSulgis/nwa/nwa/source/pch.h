#include	<windows.h>
#include	<tchar.h>
#include	<vector>

