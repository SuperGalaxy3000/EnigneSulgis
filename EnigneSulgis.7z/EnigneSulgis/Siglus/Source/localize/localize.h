﻿#pragma		once

#include	"../resource.h"

#if 0
#elif defined(__SIGLUS_DE)
#include	"localize/localize_de.h"
#elif defined(__SIGLUS_EN)
#include	"localize/localize_en.h"
#elif defined(__SIGLUS_ES)
#include	"localize/localize_es.h"
#elif defined(__SIGLUS_JA)
#include	"localize/localize_ja.h"
#elif defined(__SIGLUS_ZH)
#include	"localize/localize_zh.h"
#elif defined(__SIGLUS_ZHTW)
#include	"localize/localize_zhtw.h"
#elif defined(__SIGLUS_ID)
#include	"localize/localize_id.h"
#elif defined(__SIGLUS_FR)
#include	"localize/localize_fr.h"
#endif

