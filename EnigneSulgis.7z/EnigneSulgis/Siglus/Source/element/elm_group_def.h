#pragma		once

// ****************************************************************
// �O���[�v�̒萔
// ================================================================
const int	TNM_GROUP_NOT_DECIDED = -2;
const int	TNM_GROUP_CANCELED = -1;

const int	TNM_GROUP_RESULT_DECIDED = 1;
const int	TNM_GROUP_RESULT_NONE = 0;
const int	TNM_GROUP_RESULT_CANCELLED = -1;
