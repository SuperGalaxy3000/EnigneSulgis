#pragma		once

class C_tnm_net : public C_network
{

};