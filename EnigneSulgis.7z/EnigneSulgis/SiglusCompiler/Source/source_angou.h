#pragma		once

#include	"tnm_source_angou.h"

// ****************************************************************
// �^�C���Í�
// ================================================================
class C_tnms_source_angou
{
public:
	static	void	encryption(BYTE *buf, DWORD buf_size, CTSTR& buf_name, BUFFER& dst_buf);		// �Í���

};
