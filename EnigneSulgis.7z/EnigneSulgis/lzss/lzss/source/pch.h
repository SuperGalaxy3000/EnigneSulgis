#include	<windows.h>
#include	<vector>

